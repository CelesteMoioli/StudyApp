export const environment = {
  production: true,
  cognito: {
    region: 'us-east-2',
    userPoolId: 'us-east-2_qELFXPeXl',
    clientId: '5pkiqvlajre00djkjck5o26k9t'
  }
};
