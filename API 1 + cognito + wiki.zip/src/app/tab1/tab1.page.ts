import { Component } from '@angular/core';

interface StudyRoom {
  name: string;
  icon: string;
  members: number;
  activity: string;
  color: string;
}

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: false,
})
export class Tab1Page {
  rooms: StudyRoom[] = [
    { name: 'Matematicas', icon: 'calculator-outline', members: 12, activity: 'hoy', color: 'primary-dark' },
    { name: 'Fisica', icon: 'planet-outline', members: 9, activity: 'ayer', color: 'primary' },
    { name: 'Programacion', icon: 'code-slash', members: 15, activity: 'hoy', color: 'secondary' },
    { name: 'Historia', icon: 'business', members: 8, activity: 'hace 2 dias', color: 'info' }
  ];

  constructor() {}
}
