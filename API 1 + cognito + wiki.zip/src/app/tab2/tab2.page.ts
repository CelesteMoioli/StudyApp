import { Component } from '@angular/core';

interface CalendarEvent {
  type: string;
  title: string;
  subject: string;
  time: string;
  color: string;
}

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  standalone: false,
})
export class Tab2Page {
  selectedDay = 22;
  days = [20, 21, 22, 23, 24, 25, 26];
  events: CalendarEvent[] = [
    { type: 'Entrega', title: 'Tarea: Derivadas', subject: 'Matematicas', time: '23:59', color: 'primary' },
    { type: 'Examen', title: 'Examen Parcial', subject: 'Fisica', time: '10:00', color: 'info' },
    { type: 'Proyecto', title: 'Entrega: Prototipo', subject: 'Programacion', time: '23:59', color: 'warning' },
    { type: 'Reunion', title: 'Reunion de equipo Alfa', subject: 'Matematicas', time: '16:00', color: 'secondary' }
  ];

  constructor() {}

}
