import { Component } from '@angular/core';

interface ResourceItem {
  title: string;
  subject: string;
  meta: string;
  badge: string;
  color: string;
}

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  standalone: false,
})
export class Tab3Page {
  filters = ['Todos', 'Documentos', 'Presentaciones', 'Videos'];
  resources: ResourceItem[] = [
    { title: 'Formulario integrales.pdf', subject: 'Matematicas', meta: 'PDF · Subido ayer', badge: 'PDF', color: 'red' },
    { title: 'Presentacion Ondas.pptx', subject: 'Fisica', meta: 'PPTX · Subido hace 2 dias', badge: 'PPT', color: 'orange' },
    { title: 'Guia de Algoritmos.docx', subject: 'Programacion', meta: 'DOCX · Subido hace 3 dias', badge: 'DOC', color: 'blue' },
    { title: 'Clase 5 - Cinematica.mp4', subject: 'Fisica', meta: 'MP4 · Subido hace 4 dias', badge: 'VID', color: 'teal' }
  ];

  constructor() {}

}
