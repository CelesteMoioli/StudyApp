import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss'],
  standalone: false,
})
export class TabsPage {
  hideTabBar = false;

  constructor() {}

  @HostListener('window:studyapp-reader-mode', ['$event'])
  onReaderMode(event: CustomEvent<boolean>): void {
    // La Wiki puede pedir pantalla completa para leer mejor y ocultar la barra inferior.
    this.hideTabBar = Boolean(event.detail);
  }

}
