import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ActionSheetController, AlertController, LoadingController, ModalController, ToastController } from '@ionic/angular';
import { Storage } from '@angular/fire/storage';
import { getDownloadURL, ref as storageRef, uploadBytes } from 'firebase/storage';
import { Subscription } from 'rxjs';
import { DbService } from '../services/db.service';
import { AuthService } from '../services/auth.service';
import { DocumentoEditorComponent } from '../sala-detalle/documento-editor/documento-editor.component';
import { WikiSelectorModalComponent } from '../shared/wiki-selector/wiki-selector-modal.component';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  standalone: false,
})
export class Tab3Page implements OnInit, OnDestroy {
  @ViewChild('uploadInput') uploadInput?: ElementRef<HTMLInputElement>;
  @ViewChild('localInput') localInput?: ElementRef<HTMLInputElement>;

  recursos: any[] = [];
  recursosLocales: any[] = [];
  recursosFiltrados: any[] = [];
  bibliotecaItems: any[] = [];
  salas: any[] = [];
  salasConDocumentos: any[] = [];
  documentosSala: any[] = [];
  documentosSalaFiltrados: any[] = [];

  filtroSeleccionado = 'Todos';
  vistaSeleccionada = 'Todos';
  textoBusqueda = '';
  salaDocumentoSeleccionada = 'Todas';
  userName = '';
  visorAbierto = false;
  recursoEnVisor: any = null;
  visorUrl: SafeResourceUrl | null = null;
  visorUrlExterna = '';
  favoritos = new Set<string>();
  favoritosKey = 'studyapp_resource_favorites';

  private sub?: Subscription;
  private salasSub?: Subscription;
  private docsSub?: Subscription;

  tipoClass: Record<string, string> = {
    PDF: 'pdf',
    PPTX: 'ppt',
    DOCX: 'doc',
    MP4: 'video',
    JPG: 'image',
    JPEG: 'image',
    PNG: 'image',
    WEBP: 'image',
    GIF: 'image',
    TXT: 'doc',
    MD: 'doc',
    HTML: 'doc',
    NOTE: 'doc'
  };

  constructor(
    private actionSheetController: ActionSheetController,
    private alertController: AlertController,
    private loadingController: LoadingController,
    private modalController: ModalController,
    private toastController: ToastController,
    private sanitizer: DomSanitizer,
    private auth: AuthService,
    private db: DbService,
    private storage: Storage
  ) {}


  /** 
  * @function ngOnInit
  * @description Inicializa el componente y configura los recursos. 
  */
  async ngOnInit(): Promise<void> {
    const user = await this.auth.getCurrentUser();
    this.userName = user?.name || user?.username || 'Estudiante';
    this.favoritosKey = `studyapp_resource_favorites_${user?.email || 'anonimo'}`;
    this.cargarFavoritos();

    this.sub = this.db.listenRecursos().subscribe(recursos => {
      this.recursos = recursos;
      this.actualizarBiblioteca();
    });

    this.salasSub = this.db.listenSalas().subscribe(salas => {
      this.salas = salas;
      this.actualizarBiblioteca();
    });

    this.docsSub = this.db.listenTodosDocumentos().subscribe(documentos => {
      this.documentosSala = documentos;
      this.actualizarBiblioteca();
    });
  }


  /** 
  * @function ngOnDestroy
  * @description Limpia la suscripción al destruir el componente. 
  */
  ngOnDestroy(): void {
    this.sub?.unsubscribe();
    this.salasSub?.unsubscribe();
    this.docsSub?.unsubscribe();
    this.recursosLocales.forEach(recurso => {
      if (recurso.localUrl) {
        URL.revokeObjectURL(recurso.localUrl);
      }
    });
  }


  /** 
  * @function getIconClass
  * @description Devuelve la clase CSS para el icono del recurso según su tipo. 
  */
  getIconClass(tipo: string): string {
    return this.tipoClass[tipo?.toUpperCase()] ?? 'doc';
  }


  /** 
  * @function isVideo
  * @description Devuelve true si el recurso es un video. 
  */
  isVideo(tipo: string): boolean {
    return ['MP4', 'MOV', 'AVI', 'WEBM', 'MKV'].includes(tipo?.toUpperCase());
  }

  isImage(tipo: string): boolean {
    return ['JPG', 'JPEG', 'PNG', 'WEBP', 'GIF', 'BMP', 'SVG'].includes(tipo?.toUpperCase());
  }

  isPdf(tipo: string): boolean {
    return tipo?.toUpperCase() === 'PDF';
  }

  isOffice(tipo: string): boolean {
    return ['DOC', 'DOCX', 'PPT', 'PPTX', 'XLS', 'XLSX'].includes(tipo?.toUpperCase());
  }

  isText(tipo: string): boolean {
    return ['TXT', 'MD'].includes(tipo?.toUpperCase());
  }

  isHtml(tipo: string): boolean {
    return tipo?.toUpperCase() === 'HTML';
  }

  isNotaManual(tipo: string): boolean {
    return tipo?.toUpperCase() === 'NOTE';
  }

  puedePrevisualizar(recurso: any): boolean {
    return this.isImage(recurso?.tipo) ||
      this.isVideo(recurso?.tipo) ||
      this.isPdf(recurso?.tipo) ||
      this.isText(recurso?.tipo) ||
      this.isHtml(recurso?.tipo) ||
      this.isNotaManual(recurso?.tipo);
  }


  /** 
  * @function seleccionarFiltro
  * @description Selecciona un filtro para los recursos. 
  */
  seleccionarFiltro(filtro: string): void {
    this.filtroSeleccionado = filtro;
    this.actualizarBiblioteca();
  }

  seleccionarVista(vista: string): void {
    this.vistaSeleccionada = vista;
    this.actualizarBiblioteca();
  }


  /** 
  * @function buscar
  * @description Busca recursos por nombre o materia. 
  */
  buscar(event: any): void {
    this.textoBusqueda = event.detail.value ?? '';
    this.actualizarBiblioteca();
  }


  /** 
  * @function aplicarFiltro
  * @description Aplica el filtro seleccionado a los recursos. 
  */
  aplicarFiltro(): void {
    this.actualizarBiblioteca();
  }

  actualizarBiblioteca(): void {
    const recursos = [...this.recursos, ...this.recursosLocales]
      .filter(recurso => this.esRecursoAccionable(recurso))
      .map(recurso => ({
        ...recurso,
        kind: 'recurso',
        titulo: recurso.nombre,
        subtitulo: recurso.materia || 'General',
        fechaOrden: recurso.timestamp ?? (Date.parse(recurso.fechaSubida || '') || 0)
      }));

    const salasConDocsIds = new Set(this.documentosSala.map(doc => doc.salaId));
    this.salasConDocumentos = this.salas.filter(sala => salasConDocsIds.has(sala.id));

    if (this.salaDocumentoSeleccionada !== 'Todas' && !salasConDocsIds.has(this.salaDocumentoSeleccionada)) {
      this.salaDocumentoSeleccionada = 'Todas';
    }

    const documentos = this.documentosSala.map(doc => ({
      ...doc,
      kind: 'documentoSala',
      tipo: 'DOCSALA',
      titulo: doc.titulo,
      subtitulo: this.obtenerNombreSala(doc.salaId),
      fechaOrden: doc.ultimaEdicion ?? doc.fechaCreacion ?? 0
    }));

    let resultado = [...recursos, ...documentos];

    switch (this.vistaSeleccionada) {
      case 'Favoritos':
        resultado = resultado.filter(item => this.esFavorito(item));
        break;

      case 'Archivos':
        resultado = resultado.filter(item => item.kind === 'recurso');
        break;

      case 'Salas':
        resultado = resultado.filter(item => item.kind === 'documentoSala');
        break;
    }

    switch (this.filtroSeleccionado) {

      case 'Documentos':
        resultado = resultado.filter(r =>
          r.kind === 'documentoSala' || ['PDF', 'TXT', 'MD', 'HTML', 'NOTE'].includes(
            r.tipo?.toUpperCase()
          )
        );
        break;

      case 'Notas':
        resultado = resultado.filter(r =>
          r.tipo?.toUpperCase() === 'NOTE'
        );
        break;

      case 'Videos':
        resultado = resultado.filter(r =>
          ['MP4', 'AVI', 'MOV', 'WEBM', 'MKV'].includes(
            r.tipo?.toUpperCase()
          )
        );
        break;

      case 'Imagenes':
        resultado = resultado.filter(r =>
          ['JPG', 'JPEG', 'PNG', 'WEBP', 'GIF', 'BMP', 'SVG'].includes(
            r.tipo?.toUpperCase()
          )
        );
        break;
    }

    if (this.salaDocumentoSeleccionada !== 'Todas') {
      resultado = resultado.filter(item =>
        item.kind !== 'documentoSala' || item.salaId === this.salaDocumentoSeleccionada
      );
    }

    if (this.textoBusqueda.trim()) {

      const texto = this.textoBusqueda.toLowerCase();

      resultado = resultado.filter(r =>
        r.titulo?.toLowerCase().includes(texto) ||
        r.nombre?.toLowerCase().includes(texto) ||
        r.materia?.toLowerCase().includes(texto) ||
        r.subtitulo?.toLowerCase().includes(texto) ||
        r.autor?.toLowerCase().includes(texto)
      );
    }

    this.bibliotecaItems = resultado.sort((a, b) => {
      const favDiff = Number(this.esFavorito(b)) - Number(this.esFavorito(a));
      if (favDiff !== 0) return favDiff;
      return (b.fechaOrden ?? 0) - (a.fechaOrden ?? 0);
    });
    this.recursosFiltrados = this.bibliotecaItems.filter(item => item.kind === 'recurso');
    this.actualizarDocumentosSalaDesdeBiblioteca();
  }

  seleccionarSalaDocumentos(salaId: string): void {
    this.salaDocumentoSeleccionada = salaId;
    this.actualizarBiblioteca();
  }

  async abrirDocumentoSala(doc: any): Promise<void> {
    await this.abrirEditor(doc);
  }

  async abrirItem(item: any): Promise<void> {
    if (item.kind === 'documentoSala') {
      await this.abrirDocumentoSala(item);
      return;
    }

    this.abrirRecurso(item);
  }

  toggleFavorito(event: Event, item: any): void {
    event.stopPropagation();
    const id = this.getItemId(item);

    if (this.favoritos.has(id)) {
      this.favoritos.delete(id);
    } else {
      this.favoritos.add(id);
    }

    localStorage.setItem(this.favoritosKey, JSON.stringify([...this.favoritos]));
    this.actualizarBiblioteca();
  }

  async abrirOpcionesExportacionDocumento(event: Event, item: any): Promise<void> {
    event.stopPropagation();
    if (item.kind !== 'documentoSala') return;

    const actionSheet = await this.actionSheetController.create({
      header: 'Exportar documento',
      buttons: [
        {
          text: 'PDF',
          icon: 'document-outline',
          handler: () => this.exportarDocumentoSalaPdf(item)
        },
        {
          text: 'HTML',
          icon: 'download-outline',
          handler: () => this.exportarDocumentoSalaHtml(item)
        },
        {
          text: 'Cancelar',
          icon: 'close-outline',
          role: 'cancel'
        }
      ]
    });

    await actionSheet.present();
  }

  async exportarDocumentoSalaPdf(item: any): Promise<void> {
    const { nombre, html } = this.crearDocumentoSalaExportable(item);
    const contenedor = document.createElement('div');
    contenedor.innerHTML = html;
    contenedor.style.position = 'fixed';
    contenedor.style.left = '-10000px';
    contenedor.style.top = '0';
    contenedor.style.width = '794px';
    document.body.appendChild(contenedor);

    try {
      const html2pdf = (await import('html2pdf.js')).default;
      await html2pdf()
        .set({
          margin: 12,
          filename: `${nombre}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        })
        .from(contenedor)
        .save();
    } catch {
      await this.mostrarToast('No se pudo generar el PDF.');
    } finally {
      document.body.removeChild(contenedor);
    }
  }

  exportarDocumentoSalaHtml(item: any): void {
    const { nombre, html } = this.crearDocumentoSalaExportable(item);
    this.descargarHtml(nombre, html);
  }

  private crearDocumentoSalaExportable(item: any): { nombre: string; html: string } {
    const sala = item.subtitulo || this.obtenerNombreSala(item.salaId);
    const titulo = item.titulo || 'documento';
    const nombre = this.limpiarNombreArchivo(`${sala}-${titulo}`);
    const fecha = item.ultimaEdicion || item.fechaCreacion;
    const fechaTexto = fecha ? new Date(fecha).toLocaleString('es-AR') : '';
    const contenido = item.contenido || '<p>Sin contenido.</p>';
    const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>${this.escaparHtml(titulo)}</title>
  <style>
    body { font-family: Arial, sans-serif; color: #111827; margin: 32px; line-height: 1.5; }
    header { border-bottom: 1px solid #d1d5db; margin-bottom: 24px; padding-bottom: 16px; }
    h1 { margin: 0 0 8px; font-size: 28px; }
    .meta { color: #4b5563; font-size: 13px; }
    img { max-width: 100%; height: auto; }
    table { border-collapse: collapse; width: 100%; }
    td, th { border: 1px solid #d1d5db; padding: 6px; }
    @media print { body { margin: 18mm; } }
  </style>
</head>
<body>
  <header>
    <h1>${this.escaparHtml(titulo)}</h1>
    <div class="meta">Sala: ${this.escaparHtml(sala)} · Autor: ${this.escaparHtml(item.autor || 'Sin autor')} · ${this.escaparHtml(fechaTexto)}</div>
  </header>
  <main>${contenido}</main>
</body>
</html>`;

    return { nombre, html };
  }

  esFavorito(item: any): boolean {
    return this.favoritos.has(this.getItemId(item));
  }

  getItemId(item: any): string {
    if (item.kind === 'documentoSala') {
      return `doc:${item.salaId}:${item.id}`;
    }

    return `recurso:${item.id || item.storagePath || item.nombre}`;
  }

  getItemIconClass(item: any): string {
    return item.kind === 'documentoSala' ? 'doc-room' : this.getIconClass(item.tipo);
  }

  getItemMeta(item: any): string {
    if (item.kind === 'documentoSala') {
      const fecha = item.ultimaEdicion || item.fechaCreacion;
      return `${item.autor || 'Sin autor'} · ${fecha ? new Date(fecha).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : 'Sin fecha'}`;
    }

    return `${item.tipo || 'NOTE'} · ${item.origen === 'local' ? 'Local' : 'Disponible'}`;
  }


  /** 
  * @function nuevoRecurso
  * @description Crea un nuevo recurso. 
  */
  async nuevoRecurso(): Promise<void> {
    const actionSheet = await this.actionSheetController.create({
      header: 'Agregar recurso',
      buttons: [
        {
          text: 'Subir a Firebase',
          icon: 'cloud-upload-outline',
          handler: () => this.seleccionarArchivoParaSubir()
        },
        {
          text: 'Abrir desde mi dispositivo',
          icon: 'folder-open-outline',
          handler: () => this.seleccionarArchivoLocal()
        },
        {
          text: 'Crear nota manual',
          icon: 'document-text-outline',
          handler: () => this.crearFichaManual()
        },
        {
          text: 'Cancelar',
          icon: 'close-outline',
          role: 'cancel'
        }
      ]
    });

    await actionSheet.present();
  }

  seleccionarArchivoParaSubir(): void {
    this.uploadInput?.nativeElement.click();
  }

  seleccionarArchivoLocal(): void {
    this.localInput?.nativeElement.click();
  }

  async subirArchivoSeleccionado(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';

    if (!file) return;

    if (!this.esArchivoLegible(file.name)) {
      await this.mostrarToast('Ese formato no tiene visor interno. UsÃ¡ PDF, imagen, video, TXT, MD o HTML.');
      return;
    }

    const materia = await this.pedirMateria(file.name);
    if (materia === null) return;

    const loading = await this.loadingController.create({
      message: 'Subiendo recurso...'
    });
    await loading.present();

    try {
      const tipo = this.obtenerExtension(file.name);
      const path = `recursos/${Date.now()}-${this.limpiarNombreArchivo(file.name)}`;
      const fileRef = storageRef(this.storage, path);

      await uploadBytes(fileRef, file, {
        contentType: file.type || undefined
      });

      const url = await getDownloadURL(fileRef);

      this.db.addRecurso({
        nombre: file.name,
        materia,
        tipo,
        url,
        storagePath: path,
        mimeType: file.type,
        size: file.size,
        origen: 'firebase'
      });

      await this.mostrarToast('Recurso subido correctamente.');
    } catch (error) {
      await this.mostrarToast('No se pudo subir. Revisá Firebase Storage y sus reglas.');
    } finally {
      await loading.dismiss();
    }
  }

  async abrirArchivoLocal(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';

    if (!file) return;

    if (!this.esArchivoLegible(file.name)) {
      await this.mostrarToast('Ese formato no tiene visor interno. UsÃ¡ PDF, imagen, video, TXT, MD o HTML.');
      return;
    }

    const localUrl = URL.createObjectURL(file);
    const recurso = {
      id: `local-${Date.now()}`,
      nombre: file.name,
      materia: 'Archivo local',
      tipo: this.obtenerExtension(file.name),
      localUrl,
      mimeType: file.type,
      size: file.size,
      origen: 'local',
      fechaSubida: 'solo esta sesion'
    };

    this.recursosLocales.unshift(recurso);
    this.aplicarFiltro();
    this.abrirRecurso(recurso);
  }

  abrirRecurso(recurso: any): void {
    const url = recurso.url || recurso.localUrl;

    if (!url && !this.isNotaManual(recurso.tipo)) {
      this.mostrarToast('Este recurso todavia no tiene archivo asociado.');
      return;
    }

    this.recursoEnVisor = recurso;
    this.visorUrlExterna = url || '';
    this.visorUrl = url ? this.sanitizer.bypassSecurityTrustResourceUrl(this.obtenerUrlVisor(recurso, url)) : null;
    this.visorAbierto = true;
  }

  cerrarVisor(): void {
    this.visorAbierto = false;
    this.recursoEnVisor = null;
    this.visorUrl = null;
    this.visorUrlExterna = '';
  }

  abrirRecursoExterno(): void {
    if (this.visorUrlExterna) {
      window.open(this.visorUrlExterna, '_blank');
    }
  }

  exportarRecursoManual(): void {
    if (!this.recursoEnVisor || !this.isNotaManual(this.recursoEnVisor.tipo)) return;

    const nombre = this.limpiarNombreArchivo(this.recursoEnVisor.nombre || 'nota');
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${this.escaparHtml(this.recursoEnVisor.nombre)}</title></head><body><h1>${this.escaparHtml(this.recursoEnVisor.nombre)}</h1><p><strong>Materia:</strong> ${this.escaparHtml(this.recursoEnVisor.materia || '')}</p><pre style="white-space:pre-wrap;font-family:Arial,sans-serif">${this.escaparHtml(this.recursoEnVisor.contenido || '')}</pre></body></html>`;
    this.descargarHtml(nombre, html);
  }

  async crearFichaManual(): Promise<void> {

    const alert = await this.alertController.create({
      header: 'Nueva nota',
      inputs: [
        {
          name: 'nombre',
          type: 'text',
          placeholder: 'Titulo'
        },
        {
          name: 'materia',
          type: 'text',
          placeholder: 'Materia'
        },
        {
          name: 'contenido',
          type: 'textarea',
          placeholder: 'Contenido de la nota'
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Agregar',
          handler: (data) => {

            if (!data.nombre?.trim()) {
              return false;
            }

            this.db.addRecurso({
              nombre: data.nombre.trim(),
              materia: data.materia?.trim() ?? '',
              tipo: 'NOTE',
              contenido: data.contenido?.trim() ?? '',
              origen: 'manual',
              exportable: true
            });

            return true;
          }
        }
      ]
    });

    await alert.present();
  }

  private async pedirMateria(nombreArchivo: string): Promise<string | null> {
    return new Promise(async resolve => {
      const alert = await this.alertController.create({
        header: 'Datos del recurso',
        subHeader: nombreArchivo,
        inputs: [
          {
            name: 'materia',
            type: 'text',
            placeholder: 'Materia o categoria'
          }
        ],
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel',
            handler: () => resolve(null)
          },
          {
            text: 'Subir',
            handler: data => resolve(data.materia?.trim() || 'General')
          }
        ]
      });

      await alert.present();
    });
  }

  private obtenerExtension(nombre: string): string {
    const partes = nombre.split('.');
    return partes.length > 1 ? partes.pop()!.toUpperCase() : 'FILE';
  }

  private esArchivoLegible(nombre: string): boolean {
    const tipo = this.obtenerExtension(nombre);
    return ['PDF', 'JPG', 'JPEG', 'PNG', 'WEBP', 'GIF', 'BMP', 'SVG', 'MP4', 'WEBM', 'MOV', 'TXT', 'MD', 'HTML'].includes(tipo);
  }

  private limpiarNombreArchivo(nombre: string): string {
    return nombre
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9._-]/g, '-');
  }

  private obtenerUrlVisor(recurso: any, url: string): string {
    const tipo = recurso.tipo?.toUpperCase();

    if (this.isOffice(tipo)) return '';
    return url;
  }

  private escaparHtml(valor: string): string {
    return String(valor ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  private descargarHtml(nombre: string, html: string): void {
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${nombre}.html`;
    link.click();
    URL.revokeObjectURL(url);
  }

  private esRecursoAccionable(recurso: any): boolean {
    return Boolean(recurso?.url || recurso?.localUrl || this.isNotaManual(recurso?.tipo));
  }

  private cargarFavoritos(): void {
    try {
      this.favoritos = new Set(JSON.parse(localStorage.getItem(this.favoritosKey) || '[]'));
    } catch {
      this.favoritos = new Set();
    }
  }

  private async mostrarToast(message: string): Promise<void> {
    const toast = await this.toastController.create({
      message,
      duration: 2200,
      position: 'bottom'
    });
    await toast.present();
  }

  private actualizarDocumentosSala(): void {
    this.actualizarBiblioteca();
  }

  private actualizarDocumentosSalaDesdeBiblioteca(): void {
    const salasConDocsIds = new Set(this.documentosSala.map(doc => doc.salaId));
    this.salasConDocumentos = this.salas.filter(sala => salasConDocsIds.has(sala.id));

    if (this.salaDocumentoSeleccionada !== 'Todas' && !salasConDocsIds.has(this.salaDocumentoSeleccionada)) {
      this.salaDocumentoSeleccionada = 'Todas';
    }

    this.documentosSalaFiltrados = this.bibliotecaItems.filter(item => item.kind === 'documentoSala');
  }

  private obtenerNombreSala(salaId: string): string {
    return this.salas.find(sala => sala.id === salaId)?.nombre ?? 'Sala';
  }

  private async abrirEditor(documento: any): Promise<void> {
    const modal = await this.modalController.create({
      component: DocumentoEditorComponent,
      componentProps: {
        salaId: documento.salaId,
        autor: this.userName,
        documento
      }
    });

    modal.onDidDismiss().then(async ({ data }) => {
      if (data?.abrirWiki) {
        const wikiHtml = await this.abrirWikiModal();
        if (wikiHtml) {
          await this.abrirEditorConWiki(documento, data.titulo, data.contenidoActual, wikiHtml);
        }
      }
    });

    await modal.present();
  }

  private async abrirEditorConWiki(documento: any, titulo: string, contenidoActual: string, wikiHtml: string): Promise<void> {
    const modal = await this.modalController.create({
      component: DocumentoEditorComponent,
      componentProps: {
        salaId: documento.salaId,
        autor: this.userName,
        documento,
        wikiHtml,
        titulo,
        contenidoPrevio: contenidoActual
      }
    });

    modal.onDidDismiss().then(async ({ data }) => {
      if (data?.abrirWiki) {
        const wikiHtml2 = await this.abrirWikiModal();
        if (wikiHtml2) {
          await this.abrirEditorConWiki(documento, data.titulo, data.contenidoActual, wikiHtml2);
        }
      }
    });

    await modal.present();
  }

  private async abrirWikiModal(): Promise<string | null> {
    const modal = await this.modalController.create({
      component: WikiSelectorModalComponent
    });
    await modal.present();
    const { data } = await modal.onDidDismiss();
    return data?.wikiHtml ?? null;
  }
}
