import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IonContent, ModalController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { DbService } from '../services/db.service';
import { DocumentoEditorComponent } from './documento-editor/documento-editor.component';
import { WikiSelectorModalComponent } from '../shared/wiki-selector/wiki-selector-modal.component';

@Component({
  selector: 'app-sala-detalle',
  templateUrl: 'sala-detalle.page.html',
  styleUrls: ['sala-detalle.page.scss'],
  standalone: false,
})
export class SalaDetallePage implements OnInit, OnDestroy {
  @ViewChild(IonContent) content!: IonContent;
  salaId = '';
  salaNombre = '';
  mensajes: any[] = [];
  presencia: any[] = [];
  documentos: any[] = [];
  nuevoMensaje = '';
  userEmail = '';
  userId = '';
  userName = '';

  private chatSub?: Subscription;
  private presSub?: Subscription;
  private docSub?: Subscription;

  constructor(
    private route: ActivatedRoute,
    private auth: AuthService,
    private db: DbService,
    private modalController: ModalController
  ) {}


  /**
   * @function ngOnInit
   * @description Se ejecuta al inicializar el componente. 
   * Obtiene el ID y nombre de la sala desde la ruta, recupera el usuario actual, se une a la sala y se suscribe a los cambios en presencia, chat y documentos.
   */
  async ngOnInit(): Promise<void> {
    this.salaId = this.route.snapshot.paramMap.get('id') ?? '';
    this.salaNombre = this.route.snapshot.paramMap.get('nombre') ?? '';
    const user = await this.auth.getCurrentUser();
    if (!user) return;
    this.userEmail = user.email;
    this.userId = user.username;
    this.userName = await this.obtenerNombreVisible(user.email, user.name);
    await this.db.joinSala(this.salaId, this.userEmail, this.userName);
    this.presSub = this.db.listenPresencia(this.salaId).subscribe(p => this.cargarPresenciaConNombres(p));
    this.chatSub = this.db.listenChat(this.salaId).subscribe(msgs => {
      this.cargarMensajesConNombres(msgs);
      setTimeout(() => this.content?.scrollToBottom(200), 50);
    });
    this.docSub = this.db.listenDocumentos(this.salaId).subscribe(docs => {
      this.documentos = docs;
    });
  }


  /**
   * @function ngOnDestroy
   * @description Se ejecuta al destruir el componente. 
   * Deja la sala, cancela las suscripciones a presencia, chat y documentos para evitar fugas de memoria.
   */
  ngOnDestroy(): void {
    this.db.leaveSala(this.salaId, this.userEmail);
    this.chatSub?.unsubscribe();
    this.presSub?.unsubscribe();
    this.docSub?.unsubscribe();
  }


  /**
   * @function enviar
   * @description Envía un mensaje a la sala.
   */
  enviar(): void {
    const texto = this.nuevoMensaje.trim();
    if (!texto) return;
    this.db.sendMessage(this.salaId, {
      texto,
      autor: this.userName,
      email: this.userEmail,
      userId: this.userId
    });
    this.nuevoMensaje = '';
  }


  /**
   * @function esMio
   * @description Determina si un mensaje pertenece al usuario actual.
   */
  esMio(msg: any): boolean {
    return msg.email === this.userEmail || msg.email === this.userId || msg.userId === this.userId || msg.userId === this.userEmail;
  }


  /**
   * @function nuevoDocumento
   * @description Abre el editor de documentos para crear un nuevo documento en la sala. 
   */
  async nuevoDocumento(): Promise<void> {
    await this.abrirEditor(null);
  }


  /**
   * @function abrirDocumento
   * @description Abre el editor de documentos para ver o editar un documento existente en la sala.
   */
  async abrirDocumento(doc: any): Promise<void> {
    await this.abrirEditor(doc);
  }


  /**
   * @function abrirEditor
   * @description Abre un modal con el componente DocumentoEditorComponent para crear o editar un documento.
   */
  private async abrirEditor(documento: any): Promise<void> {
    const modal = await this.modalController.create({
      component: DocumentoEditorComponent,
      componentProps: {
        salaId: this.salaId,
        autor: this.userName,
        documento: documento ?? null
      }
    });

    modal.onDidDismiss().then(async ({ data }) => {
      if (data?.abrirWiki) {
        const wikiHtml = await this.abrirWikiModal();
        if (wikiHtml) {
          await this.abrirEditorConWiki(documento, data.titulo, data.contenidoActual, wikiHtml);
        }
      }
    });

    await modal.present();
  }


  /**
   * @function abrirEditorConWiki
   * @description Abre el editor de documentos con contenido de wiki pre-cargado. 
   */
  private async abrirEditorConWiki(documento: any, titulo: string, contenidoActual: string, wikiHtml: string): Promise<void> {
    const modal = await this.modalController.create({
      component: DocumentoEditorComponent,
      componentProps: {
        salaId: this.salaId,
        autor: this.userName,
        documento: documento ?? null,
        wikiHtml,
        titulo,
        contenidoPrevio: contenidoActual
      }
    });

    modal.onDidDismiss().then(async ({ data }) => {
      if (data?.abrirWiki) {
        const wikiHtml2 = await this.abrirWikiModal();
        if (wikiHtml2) {
          await this.abrirEditorConWiki(documento, data.titulo, data.contenidoActual, wikiHtml2);
        }
      }
    });

    await modal.present();
  }


  /**
   * @function abrirWikiModal
   * @description Abre un modal para seleccionar una página de wiki.
   */
  private async abrirWikiModal(): Promise<string | null> {
    const modal = await this.modalController.create({
      component: WikiSelectorModalComponent
    });
    await modal.present();
    const { data } = await modal.onDidDismiss();
    return data?.wikiHtml ?? null;
  }

  private async obtenerNombreVisible(email: string, fallback: string): Promise<string> {
    const perfil = await this.db.getPerfil(email);
    const nombre = perfil?.nombre || fallback;
    return this.esIdentificadorTecnico(nombre) ? fallback : nombre;
  }

  private async cargarMensajesConNombres(msgs: any[]): Promise<void> {
    const mensajes = await Promise.all(
      msgs.map(async msg => {
        if (!this.esIdentificadorTecnico(msg.autor)) {
          return msg;
        }

        return {
          ...msg,
          autor: await this.obtenerNombreVisible(msg.email, msg.autor)
        };
      })
    );

    this.mensajes = mensajes;
  }

  private async cargarPresenciaConNombres(presencia: any[]): Promise<void> {
    this.presencia = await Promise.all(
      presencia.map(async usuario => ({
        ...usuario,
        nombre: await this.obtenerNombreVisible(usuario.email, usuario.nombre)
      }))
    );
  }

  private esIdentificadorTecnico(valor: string): boolean {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(valor ?? '');
  }
}
