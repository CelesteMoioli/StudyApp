import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

type CognitoLibrary = typeof import('amazon-cognito-identity-js');
type CognitoUserPoolInstance = InstanceType<CognitoLibrary['CognitoUserPool']>;
type CognitoUserSessionInstance = InstanceType<CognitoLibrary['CognitoUserSession']>;
type CognitoUserInstance = InstanceType<CognitoLibrary['CognitoUser']>;

export interface AuthenticatedUser {
  email: string;
  username: string;
  name: string;
  idToken: string;
  accessToken: string;
}

export interface RegisterUserData {
  name: string;
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // Datos de Cognito que vienen del environment. Asi no dejamos los valores repartidos por toda la app.
  private readonly poolData = environment.cognito;
  private cognitoLibrary?: Promise<CognitoLibrary>;
  private userPool?: CognitoUserPoolInstance;


  /**
   * @function isConfigured
   * @description Verifica si el servicio de autenticación está configurado correctamente.
   */
  get isConfigured(): boolean {
    // Validamos que el User Pool tenga formato real antes de intentar loguear al usuario.
    return /^[a-z]{2}-[a-z]+-\d_[A-Za-z0-9]+$/.test(this.poolData.userPoolId) && Boolean(this.poolData.clientId);
  }


  /**
   * @function signIn
   * @description Inicia sesión con las credenciales proporcionadas.
   */
  async signIn(email: string, password: string): Promise<AuthenticatedUser> {
    // Login principal: Cognito revisa mail y clave, y si esta todo bien devuelve los tokens.
    const cognito = await this.loadCognito();
    const user = await this.createUser(email);
    const authDetails = new cognito.AuthenticationDetails({
      Username: email,
      Password: password
    });

    return new Promise((resolve, reject) => {
      user.authenticateUser(authDetails, {
        onSuccess: (session) => {
          this.mapUserSession(user, email, session).then(resolve).catch(reject);
        },
        onFailure: (error) => reject(error)
      });
    });
  }


  /**
   * @function signUp
   * @description Registra un nuevo usuario con los datos proporcionados. 
   */
  async signUp(data: RegisterUserData): Promise<void> {
    // Registro de usuario nuevo. Mandamos mail y nombre como atributos para que Cognito cree la cuenta.
    const cognito = await this.loadCognito();
    const userPool = await this.getUserPool();
    const attributes = [
      new cognito.CognitoUserAttribute({ Name: 'email', Value: data.email }),
      new cognito.CognitoUserAttribute({ Name: 'name', Value: data.name })
    ];

    return new Promise((resolve, reject) => {
      userPool.signUp(data.email, data.password, attributes, [], (error) => {
        if (error) {
          reject(error);
          return;
        }

        resolve();
      });
    });
  }


  /**
   * @function confirmSignUp
   * @description Confirma el registro de un usuario con el código recibido por correo electrónico.
   */
  async confirmSignUp(email: string, code: string): Promise<void> {
    // Confirmacion del codigo que llega por mail despues del registro.
    const user = await this.createUser(email);

    return new Promise((resolve, reject) => {
      user.confirmRegistration(code, true, (error) => {
        if (error) {
          reject(error);
          return;
        }

        resolve();
      });
    });
  }


  /**
   * @function resendConfirmationCode
   * @description Reenvía el código de confirmación a un usuario que no recibió o perdió el código original.
   */
  async resendConfirmationCode(email: string): Promise<void> {
    // Si el usuario perdio o vencio el codigo, pedimos a Cognito que mande uno nuevo.
    const user = await this.createUser(email);

    return new Promise((resolve, reject) => {
      user.resendConfirmationCode((error) => {
        if (error) {
          reject(error);
          return;
        }

        resolve();
      });
    });
  }


  /**
   * @function forgotPassword
   * @description Inicia el proceso de recuperación de contraseña.
   */
  async forgotPassword(email: string): Promise<void> {
    // Inicio de recuperacion de clave: Cognito envia un codigo al mail del usuario.
    const user = await this.createUser(email);

    return new Promise((resolve, reject) => {
      user.forgotPassword({
        onSuccess: () => resolve(),
        onFailure: (error) => reject(error),
        inputVerificationCode: () => resolve()
      });
    });
  }


  /**
   * @function confirmNewPassword
   * @description Confirma la nueva contraseña para un usuario.
   */
  async confirmNewPassword(email: string, code: string, newPassword: string): Promise<void> {
    // Cierre de recuperacion: con el codigo recibido se define una clave nueva.
    const user = await this.createUser(email);

    return new Promise((resolve, reject) => {
      user.confirmPassword(code, newPassword, {
        onSuccess: () => resolve(),
        onFailure: (error) => reject(error)
      });
    });
  }


  /**
   * @function changePassword
   * @description Cambia la contraseÃ±a del usuario autenticado.
   */
  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    const userPool = await this.getUserPool();
    const user = userPool.getCurrentUser();

    if (!user) {
      throw new Error('No hay una sesión activa.');
    }

    return new Promise((resolve, reject) => {
      user.getSession((sessionError: Error | null, session: CognitoUserSessionInstance | null) => {
        if (sessionError || !session?.isValid()) {
          reject(sessionError ?? new Error('La sesión no es válida.'));
          return;
        }

        user.changePassword(currentPassword, newPassword, (error) => {
          if (error) {
            reject(error);
            return;
          }

          resolve();
        });
      });
    });
  }


  /**
   * @function signOut
   * @description Cierra la sesión del usuario actual.
   */
  async signOut(): Promise<void> {
    // Cierra la sesion guardada por Cognito en el navegador/dispositivo.
    const userPool = await this.getUserPool();
    userPool.getCurrentUser()?.signOut();
  }


  /**
   * @function getCurrentUser
   * @description Obtiene la información del usuario autenticado.
   */
  async getCurrentUser(): Promise<AuthenticatedUser | null> {
    // Revisa si ya existe una sesion valida. Esto nos permite proteger la app al abrirla.
    const userPool = await this.getUserPool();
    const user = userPool.getCurrentUser();

    if (!user) {
      return Promise.resolve(null);
    }

    return new Promise((resolve) => {
      user.getSession((error: Error | null, session: CognitoUserSessionInstance | null) => {
        if (error || !session?.isValid()) {
          resolve(null);
          return;
        }

        this.mapUserSession(user, user.getUsername(), session).then(resolve);
      });
    });
  }


  /**
   * @function createUser
   * @description Crea una instancia de usuario de Cognito.
   */
  private async createUser(email: string) {
    // Cognito trabaja con objetos usuario; esta funcion evita repetir la misma creacion en cada operacion.
    const cognito = await this.loadCognito();
    const userPool = await this.getUserPool();

    return new cognito.CognitoUser({
      Username: email,
      Pool: userPool
    });
  }


  /**
   * @function getUserPool
   * @description Obtiene la instancia del User Pool de Cognito.
   */
  private async getUserPool(): Promise<CognitoUserPoolInstance> {
    // Creamos el User Pool una sola vez y lo reutilizamos para login, registro y recuperacion.
    if (this.userPool) {
      return this.userPool;
    }

    const cognito = await this.loadCognito();
    this.userPool = new cognito.CognitoUserPool({
      UserPoolId: this.poolData.userPoolId || 'us-east-1_placeholder',
      ClientId: this.poolData.clientId || 'placeholder'
    });

    return this.userPool;
  }


  /**
   * @function loadCognito
   * @description Carga la librería de Cognito de forma dinámica para evitar problemas de inicialización en Angular
   */
  private loadCognito(): Promise<CognitoLibrary> {
    // Import dinamico para que Angular no cargue Cognito antes de tiempo y evitar errores de inicializacion.
    this.cognitoLibrary ??= import('amazon-cognito-identity-js');
    return this.cognitoLibrary;
  }


  /**
   * @function mapSession
   * @description Mapea la sesión de Cognito a un objeto de usuario autenticado.
   */
  private async mapUserSession(
    user: CognitoUserInstance,
    username: string,
    session: CognitoUserSessionInstance
  ): Promise<AuthenticatedUser> {
    const sessionUser = this.mapSession(username, session);
    const attributes = await this.getUserAttributes(user);
    const email = attributes['email'] || sessionUser.email;
    const name = attributes['name'] || attributes['given_name'] || sessionUser.name;

    return {
      ...sessionUser,
      email,
      username,
      name: this.isTechnicalId(name) ? this.nameFromEmail(email) : name
    };
  }

  private mapSession(username: string, session: CognitoUserSessionInstance): AuthenticatedUser {
    // Dejamos la sesion en un formato simple para que el resto de la app no dependa directo de Cognito.
    const idToken = session.getIdToken().getJwtToken();
    const payload = this.decodeJwtPayload(idToken);
    const email = this.readClaim(payload, 'email') || username;
    const name = this.readClaim(payload, 'name') || this.readClaim(payload, 'given_name') || this.nameFromEmail(email);

    return {
      email,
      username,
      name,
      idToken,
      accessToken: session.getAccessToken().getJwtToken()
    };
  }

  private getUserAttributes(user: CognitoUserInstance): Promise<Record<string, string>> {
    return new Promise((resolve) => {
      user.getUserAttributes((error, attributes) => {
        if (error || !attributes) {
          resolve({});
          return;
        }

        resolve(
          attributes.reduce<Record<string, string>>((result, attribute) => {
            result[attribute.getName()] = attribute.getValue();
            return result;
          }, {})
        );
      });
    });
  }

  private decodeJwtPayload(token: string): Record<string, unknown> {
    try {
      const payload = token.split('.')[1];
      const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(
        atob(base64)
          .split('')
          .map(char => `%${char.charCodeAt(0).toString(16).padStart(2, '0')}`)
          .join('')
      );

      return JSON.parse(json);
    } catch {
      return {};
    }
  }

  private readClaim(payload: Record<string, unknown>, claim: string): string {
    const value = payload[claim];
    return typeof value === 'string' ? value.trim() : '';
  }

  private nameFromEmail(email: string): string {
    return email.includes('@') ? email.split('@')[0] : email;
  }

  private isTechnicalId(value: string): boolean {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
  }
}
