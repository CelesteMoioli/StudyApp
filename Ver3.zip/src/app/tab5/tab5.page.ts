import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { DbService } from '../services/db.service';
import { AvatarPickerComponent } from './avatar-picker/avatar-picker.component';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

@Component({
  selector: 'app-tab5',
  templateUrl: 'tab5.page.html',
  styleUrls: ['tab5.page.scss'],
  standalone: false,
})
export class Tab5Page implements OnInit, OnDestroy {
  perfil: any = {
    nombre: '',
    username: '',
    salas: 0,
    equipos: 0,
    recursos: 0,
    contribuciones: 0,
    avatarUrl: ''
  };
  userEmail = '';
  configuracionAbierta = false;
  perfilForm = {
    nombre: '',
    username: ''
  };
  claveForm = {
    actual: '',
    nueva: '',
    confirmar: ''
  };
  administrarClaveAbierto = false;
  perfilMensaje = '';
  perfilError = '';
  private salasSub?: Subscription;
  private recursosSub?: Subscription;

  constructor(
    private alertController: AlertController,
    private modalController: ModalController,
    private auth: AuthService,
    private db: DbService,
    private router: Router
  ) {}

  
  /** 
  * @function ngOnInit
  * @description Inicializa el componente. 
  */
  async ngOnInit(): Promise<void> {
    const user = await this.auth.getCurrentUser();
    if (!user) return;
    this.userEmail = user.email;
    const datos = await this.db.getPerfil(this.userEmail);
    if (datos) {
      this.perfil = datos;
      if (this.esIdentificadorTecnico(this.perfil.nombre) && user.name) {
        this.perfil.nombre = user.name;
        this.perfil.username = this.esIdentificadorTecnico(this.perfil.username) ? this.crearUsername(user.name) : this.perfil.username;
        await this.db.setPerfil(this.userEmail, this.perfil);
      }
    } else {
      this.perfil = {
        nombre: user.name,
        username: this.crearUsername(user.name),
        salas: 0,
        equipos: 0,
        recursos: 0,
        contribuciones: 0,
        avatarUrl: ''
      };
      await this.db.setPerfil(this.userEmail, this.perfil);
    }
    this.cargarEstadisticas();
  }

  private esIdentificadorTecnico(valor: string): boolean {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(valor ?? '');
  }

  private crearUsername(nombre: string): string {
    return nombre.trim().toLowerCase().replace(/\s+/g, '.');
  }


  /** 
  * @function ngOnDestroy
  * @description Limpia las suscripciones al destruir el componente.
  */
  ngOnDestroy(): void {
    this.salasSub?.unsubscribe();
    this.recursosSub?.unsubscribe();
  }


  /** 
  * @function cargarEstadisticas
  * @description Carga las estadísticas del perfil. 
  */
  private cargarEstadisticas(): void {
    this.salasSub = this.db.listenSalas().subscribe(salas => {
      this.perfil.salas = salas.length;
      this.actualizarContribuciones();
    });
    this.recursosSub = this.db.listenRecursos().subscribe(recursos => {
      this.perfil.recursos = recursos.length;
      this.actualizarContribuciones();
    });
  }


  /** 
  * @function actualizarContribuciones
  * @description Actualiza el número de contribuciones del perfil. 
  */
  private async actualizarContribuciones(): Promise<void> {
    this.perfil.contribuciones =
      this.perfil.salas + this.perfil.recursos + this.perfil.equipos;
    await this.db.setPerfil(this.userEmail, this.perfil);
  }


  /** 
  * @function cambiarAvatar
  * @description Cambia el avatar del perfil. 
  */
  async cambiarAvatar(): Promise<void> {
    const alert = await this.alertController.create({
      header: 'Foto de perfil',
      buttons: [
  {
    text: 'Elegir avatar',
    cssClass: 'alert-button-avatar',
    handler: () => {
      this.abrirAvatarPicker();
      return false;
    }
  },
  {
    text: 'Tomar foto',
    handler: () => {
      this.tomarFoto(CameraSource.Camera);
      return false;
    }
  },
  {
    text: 'Elegir de galería',
    handler: () => {
      this.tomarFoto(CameraSource.Photos);
      return false;
    }
  },
  {
    text: 'Cancelar',
    role: 'cancel'
  }
]
    });
    await alert.present();
  }


  /** 
  * @function abrirAvatarPicker
  * @description Abre el selector de avatares. 
  */
  async abrirAvatarPicker(): Promise<void> {
    const modal = await this.modalController.create({
      component: AvatarPickerComponent,
      breakpoints: [0, 0.75, 1],
      initialBreakpoint: 0.75
    });
    await modal.present();
    const { data } = await modal.onDidDismiss();
    if (data?.avatar) {
      this.perfil.avatarUrl = data.avatar;
      await this.db.setPerfil(this.userEmail, this.perfil);
    }
  }


  /** 
  * @function tomarFoto
  * @description Toma una foto con la cámara. 
  */
  async tomarFoto(source: CameraSource): Promise<void> {
    try {
      const image = await Camera.getPhoto({
        quality: 80,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: source
      });
      if (image.dataUrl) {
        this.perfil.avatarUrl = image.dataUrl;
        await this.db.setPerfil(this.userEmail, this.perfil);
      }
    } catch (e) {
      // usuario canceló
    }
  }


  /** 
  * @function editarPerfil
  * @description Edita el perfil del usuario. 
  */
  async abrirConfiguracion(): Promise<void> {
    this.perfilForm = {
      nombre: this.perfil.nombre,
      username: this.perfil.username
    };
    this.claveForm = {
      actual: '',
      nueva: '',
      confirmar: ''
    };
    this.administrarClaveAbierto = false;
    this.perfilMensaje = '';
    this.perfilError = '';
    this.configuracionAbierta = true;
  }
  cerrarConfiguracion(): void {
    this.configuracionAbierta = false;
  }

  async guardarConfiguracion(): Promise<void> {
    const nombre = this.perfilForm.nombre.trim();
    const username = this.perfilForm.username.trim();

    if (!nombre) {
      this.perfilError = 'El nombre no puede quedar vacío.';
      this.perfilMensaje = '';
      return;
    }

    this.perfil.nombre = nombre;
    this.perfil.username = username || this.crearUsername(nombre);
    await this.db.setPerfil(this.userEmail, this.perfil);
    this.perfilMensaje = 'Perfil actualizado correctamente.';
    this.perfilError = '';
  }

  alternarAdministrarClave(): void {
    this.administrarClaveAbierto = !this.administrarClaveAbierto;
    this.perfilMensaje = '';
    this.perfilError = '';
  }

  async cambiarClave(): Promise<void> {
    const actual = this.claveForm.actual;
    const nueva = this.claveForm.nueva;
    const confirmar = this.claveForm.confirmar;

    if (!actual || !nueva || !confirmar) {
      this.perfilError = 'Completá la clave actual, la nueva y la confirmación.';
      this.perfilMensaje = '';
      return;
    }

    if (nueva !== confirmar) {
      this.perfilError = 'La nueva clave y la confirmación no coinciden.';
      this.perfilMensaje = '';
      return;
    }

    if (!this.claveValida(nueva)) {
      this.perfilError = 'La nueva clave debe tener 8 caracteres, mayúscula, minúscula, número y símbolo.';
      this.perfilMensaje = '';
      return;
    }

    try {
      await this.auth.changePassword(actual, nueva);
      this.claveForm = { actual: '', nueva: '', confirmar: '' };
      this.perfilMensaje = 'Clave actualizada correctamente.';
      this.perfilError = '';
    } catch {
      this.perfilError = 'No pudimos cambiar la clave. Revisá la clave actual.';
      this.perfilMensaje = '';
    }
  }

  private claveValida(clave: string): boolean {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/.test(clave);
  }

  async solicitarRecuperacionClave(): Promise<void> {
    try {
      await this.auth.forgotPassword(this.userEmail);
      this.perfilMensaje = 'Te enviamos un código de recuperación a tu mail.';
      this.perfilError = '';
    } catch {
      this.perfilError = 'No pudimos enviar el código. Intentá de nuevo.';
      this.perfilMensaje = '';
    }
  }

  async cerrarSesion(): Promise<void> {
    const deviceId = localStorage.getItem('studyapp_device_id');
    if (deviceId && this.userEmail) {
      await this.db.cerrarDispositivo(this.userEmail, deviceId);
    }

    await this.auth.signOut();
    this.router.navigateByUrl('/login');
  }
}
